<div class="navbar bg-slate-900">
	<div class="navbar-start">
		<ul class="menu menu-horizontal px-1 ">
			<li><a href="/">Falgun</a></li>
			<!-- svelte-ignore a11y-no-noninteractive-tabindex -->
			<li class="" tabindex="0">
				<a class="" href="/">
					Women
					<svg
						class="fill-current mx-0"
						xmlns="http://www.w3.org/2000/svg"
						width="20"
						height="20"
						viewBox="0 0 24 24"
						><path d="M7.41,8.58L12,13.17L16.59,8.58L18,10L12,16L6,10L7.41,8.58Z" /></svg
					>
				</a>
				<ul class="menu p-2 w-52 bg-slate-800  text-left">
					<li class=" text-left"><a href="/">Winter</a></li>
					<li tabindex="0">
						<a href="/"> <span>Saree ></span></a>
						<ul class="rounded-box w-52 p-2 bg-slate-900">
							<li><a href="/">Silk</a></li>
							<li><a href="/">Jamdani</a></li>
							<li><a href="/">Katan</a></li>
							<li>
								<div class="dropdown dropdown-hover">
									<!-- svelte-ignore a11y-label-has-associated-control -->
									<label tabindex="0" class=" m-1">Cotton</label>
									<ul
										tabindex="0"
										class="dropdown-content menu p-2 shadow bg-slate-800 rounded-box w-56 m-40"
									>
										<li><a href="/">Silk</a></li>
										<li><a href="/">Jamdani</a></li>
										<li><a href="/">Katan</a></li>
									</ul>
								</div>
							</li>
							<li><a href="/">Benaroshi</a></li>
						</ul>
					</li>
				</ul>
			</li>
			<li class=""><a class="" href="/">Men</a></li>
			<li><a class="" href="/">kids</a></li>
			<li><a class="" href="/">Accessories</a></li>
			<li><a class="" href="/">Home Decor</a></li>
			<!-- <li><a href="/">Essense of Deshal</a></li> -->
			<!-- <li><a href="/">S By Deshal</a></li> -->
			<!-- <li><a href="/">About Deshal</a></li> -->
		</ul>
	</div>
	<div class="navbar-center">Brand Logo</div>
	<div class="navbar-end">Shortcut Icons</div>
</div>
