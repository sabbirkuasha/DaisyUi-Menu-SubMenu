<script>
	import '../app.postcss';
	import Nav from '../lib/Nav.svelte';
	import DropDown from '../lib/DropDown.svelte';
</script>

<Nav />
<slot />
<DropDown />
