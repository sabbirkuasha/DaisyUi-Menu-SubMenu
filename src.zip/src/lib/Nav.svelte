<div class="navbar bg-slate-900">
	<div class="navbar-start">
		<ul class="menu menu-horizontal px-1">
			<li><a href="/">Falgun</a></li>
			<!-- svelte-ignore a11y-no-noninteractive-tabindex -->
			<li class="">
				<div class="dropdown dropdown-bottom dropdown-hover ">
					<!-- svelte-ignore a11y-label-has-associated-control -->
					<label tabindex="0" class="">Women</label>
					<ul
						tabindex="0"
						class="dropdown-content -mx-5 w-52  menu shadow bg-slate-800 rounded-lg "
					>
						<li><a class="w-full " href="/">Winter Collection</a></li>
						<li
							class="dropdown hover:bg-blue-900 flex flex-row justify-between hover:border hover:border-b-4 hover:rounded-lg dropdown-open  dropdown-right dropdown-end"
						>
							<!-- svelte-ignore a11y-label-has-associated-control -->
							<label tabindex="0" class=" hover:rounded-none hover:bg-blue-900 ">Saree</label>
							<label tabindex="0" class=" hover:rounded-none hover:bg-blue-900 ">></label>
							<ul
								tabindex="0"
								class="transition-all dropdown-content w-52 px-0 -my-48 menu shadow bg-slate-900 rounded-lg "
							>
								<li><a class="w-full " href="/">Silk</a></li>
								<li><a class="w-full " href="/">Jamdani</a></li>
								<li><a class="w-full " href="/">Katan</a></li>
								<li
									class="dropdown hover:bg-blue-900 dropdown-hover hover:border hover:border-b-4 hover:rounded-lg dropdown-right dropdown-end"
								>
									<!-- svelte-ignore a11y-label-has-associated-control -->
									<label class="">Cotton</label>
									<ul
										class="dropdown-content w-52 px-0 -my-48 menu shadow bg-slate-800 rounded-lg "
									>
										<li><a class="w-full " href="/">Plain Saree</a></li>
										<li><a class="w-full " href="/">Block Print</a></li>
										<li><a class="w-full " href="/">Vegetable Dye</a></li>
										<li><a class="w-full " href="/">Tie Dye</a></li>
										<li><a class="w-full " href="/">Tangail Noksha</a></li>
									</ul>
								</li>
								<li><a class="w-full " href="/">Benaroshi</a></li>
							</ul>
						</li>
						<li><a class="w-full " href="/">Tops</a></li>
						<li><a class="w-full " href="/">Kurti</a></li>
						<li><a class="w-full " href="/">Frock</a></li>
						<li><a class="w-full " href="/">Salwar Kameez</a></li>
						<li><a class="w-full " href="/">Two Piece</a></li>
						<li><a class="w-full " href="/">Blouse</a></li>
						<li><a class="w-full " href="/">Orna</a></li>
						<li><a class="w-full " href="/">Skirt</a></li>
						<li><a class="w-full " href="/">Pant</a></li>
						<li><a class="w-full " href="/">Shawl</a></li>
					</ul>
				</div>
			</li>
			<li class=""><a class="" href="/">Men</a></li>
			<li><a class="" href="/">kids</a></li>
			<li><a class="" href="/">Accessories</a></li>
			<li><a class="" href="/">Home Decor</a></li>
			<!-- <li><a href="/">Essense of Deshal</a></li> -->
			<!-- <li><a href="/">S By Deshal</a></li> -->
			<!-- <li><a href="/">About Deshal</a></li> -->
		</ul>
	</div>
	<div class="navbar-center">Brand Logo</div>
	<div class="navbar-end">Shortcut Icons</div>
</div>
